import tensorflow
import pandas


def handler(event, context):
    return 0