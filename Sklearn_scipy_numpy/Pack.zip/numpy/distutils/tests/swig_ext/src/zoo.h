
class Zoo{
		int n;
		char animals[10][50];
public:
		Zoo();
		void shut_up(char *animal);
		void display();
};
