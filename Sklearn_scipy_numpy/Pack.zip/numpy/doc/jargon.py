"""

======
Jargon
======

Placeholder for computer science, engineering and other jargon.

"""
from __future__ import division, absolute_import, print_function
