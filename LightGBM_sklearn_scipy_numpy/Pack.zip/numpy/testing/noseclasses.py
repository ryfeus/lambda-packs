"""
Back compatibility noseclasses module. It will import the appropriate
set of tools

"""
from .nose_tools.noseclasses import *
