import tensorflow
import lightgbm


def handler(event, context):
    return 0