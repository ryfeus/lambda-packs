__version__ = '1.0.1.post2'
debug = False
cuda = None
