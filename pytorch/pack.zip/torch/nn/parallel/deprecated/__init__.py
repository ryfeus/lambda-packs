from .distributed import DistributedDataParallel
from .distributed_cpu import DistributedDataParallelCPU

__all__ = ['DistributedDataParallel', 'DistributedDataParallelCPU']
