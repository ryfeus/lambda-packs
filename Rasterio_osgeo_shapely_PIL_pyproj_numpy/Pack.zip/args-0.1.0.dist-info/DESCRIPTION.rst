args
~~~~

This simple module gives you an elegant interface for your command line argumemnts.



