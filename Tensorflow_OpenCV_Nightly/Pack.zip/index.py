import tensorflow
import cv2


def handler(event, context):
    return 0